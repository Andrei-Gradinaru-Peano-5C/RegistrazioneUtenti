/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dati;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Andrei
 */
public class InserimentoDati {
    private String driver = "com.mysql.jdbc.Driver";
    private String databaseURL = "jdbc:mysql://localhost:3306/test";
    private String user = "root";
    private String password = "";
    
    private Connection c;
    private Statement s;

    public InserimentoDati(DatiUtente dati) {
        try {
            // carico i driver JDBC di MySQL
            Class.forName(driver);
            
            // ottengo una connessione al database
            c = DriverManager.getConnection(databaseURL, user, password);
            c.setAutoCommit(true);
            s = c.createStatement();
            String query= "INSERT INTO userinfo (user_id,pwd,name,email) "
                    + "VALUES('"+ dati.getUser_name() + "','" + dati.getPwd() + "','" + dati.getName() + "','" + dati.getEmail() + "')";
            s.executeUpdate(query);
            
        } catch (ClassNotFoundException ex) {
            dati.setFeedback(("ERRORE!: non riesco a trovare i driver JDBC di MySQL nel classpath.\n") + ex.getMessage());
        } catch (SQLException ex) {
            dati.setFeedback(("ERRORE SQL!\n") + showSQLException(ex));
        } finally {
            try { if (s!=null) s.close (); } catch (SQLException e) { dati.setFeedback(dati.getFeedback() + showSQLException(e)); }
            try { if (c!=null) c.close (); } catch (SQLException e) { dati.setFeedback(dati.getFeedback() + showSQLException(e)); }
        }
    }
    
    // Questo metodo mostra le eccezioni SQL eventualmente generate
    private static String showSQLException(java.sql.SQLException e) {
        String error = "";
        SQLException next = e;
        while (next != null) {
            error += (next.getMessage());
            error += ("Error Code: " + next.getErrorCode());
            error += ("SQL State: " + next.getSQLState());
            next = next.getNextException();
        }
        return error;
    }

}
