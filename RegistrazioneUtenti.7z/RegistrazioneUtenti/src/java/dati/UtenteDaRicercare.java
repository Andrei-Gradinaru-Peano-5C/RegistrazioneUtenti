/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dati;

/**
 *
 * @author Andrei
 */
public class UtenteDaRicercare {
    private String name = "";
    private String pwd = "";
    private String user_name = "";
    private String email = "";
    private String index = "";
    
    private boolean daRicercare = false;

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }
    
    public UtenteDaRicercare() {
    }

    public boolean isDaRicercare() {
        return daRicercare;
    }

    public void setDaRicercare(boolean daRicercare) {
        this.daRicercare = daRicercare;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    public void reset() {
        this.name = "";
        this.pwd = "";
        this.user_name = "";
        this.email = "";
        this.daRicercare = false;
        this.index = "";
    }
    
    public boolean controllo() {
        boolean b = true;
        if (this.name.equals("") ) { b=false; }
        if (this.pwd.equals("")) { b=false; }
        if (this.user_name.equals("")) { b=false; }
        if (this.index.equals("")) { b=false; }
        return b;
    }
    
}
